@javax.xml.bind.annotation.XmlSchema(namespace = "http://srv.sd/")
package sd.clt.ws;
