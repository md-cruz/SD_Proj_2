package sd.srv;

public class PictureExistsException extends Exception {
	public PictureExistsException(String message) {
		super(message);
	}
}
