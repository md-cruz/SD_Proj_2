package sd.srv;

public class InfoNotFoundException extends Exception {
	public InfoNotFoundException(String message) {
		super(message);
	}
}
